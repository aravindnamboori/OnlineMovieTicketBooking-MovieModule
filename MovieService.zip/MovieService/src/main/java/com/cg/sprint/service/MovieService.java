package com.cg.sprint.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sprint.dao.MovieDAO;
import com.cg.sprint.dto.Movie;
import com.cg.sprint.exception.InvalidMovieIdException;
@Service
public class MovieService
{
    @Autowired
    MovieDAO mdao;
    public void setMdao(MovieDAO mdao) 
    {
    	this.mdao=mdao;
    }
    
    public Movie insertMovie(Movie movie)
    {
        return mdao.save(movie);
    }
    
    public Movie getMovie(int movieId) throws InvalidMovieIdException 
    {
    	try {
    	
    	    return mdao.findById(movieId).get();
    	    }
    	catch(Exception e)
    	{
    		throw new InvalidMovieIdException("Id doesn't exist, try another");
    	}
    		
    	
    }
    
    public List<Movie> getMovies()
    {
    	return mdao.findAll();
    }
    public String deleteMovie(int movieId) throws InvalidMovieIdException 
    {
    	try 
    	   {
    	    mdao.deleteById(movieId);
    	    return "Movie Deleted Successfully";
    	    }
    	catch(Exception e)
    	{
    		throw new InvalidMovieIdException("Id doesn't exist, try another");
    	}
    }

	
	
    	
    	
}
