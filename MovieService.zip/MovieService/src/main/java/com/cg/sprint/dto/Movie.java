package com.cg.sprint.dto;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.persistence.Column;
@Entity
public class Movie 
{
   @Id	
   @Min(value = 3000)
   @Max(value=3999)
   @Column(name="movie_id")
   int movieId;
   @Column(name="movie_name")
   String movieName;
   @Column(name="movie_genre")
   String movieGenre;
   @Column(name="movie_director")
   String movieDirector;
   @Column(name="movie_length")
   int movieLength;
   @Column(name="movie_language")
   String movielanguage;
  // @JsonFormat(pattern="dd-MM-yyyy",shape=Shape.STRING)
   @Column(name="movie_release_date")
   String movieReleaseDate;
   public Movie() {}
public Movie(int movieId, String movieName, String movieGenre, String movieDirector,
		int movieLength, String movielanguage, String movieReleaseDate) {
	
	this.movieId = movieId;
	this.movieName = movieName;
	this.movieGenre = movieGenre;
	this.movieDirector = movieDirector;
	this.movieLength = movieLength;
	this.movielanguage = movielanguage;
	this.movieReleaseDate = movieReleaseDate;
}
public int getMovieId() {
	return movieId;
}
public void setMovieId(int movieId) {
	this.movieId = movieId;
}
public String getMovieName() {
	return movieName;
}
public void setMovieName(String movieName) {
	this.movieName = movieName;
}
public String getMovieGenre() {
	return movieGenre;
}
public void setMovieGenre(String movieGenre) {
	this.movieGenre = movieGenre;
}
public String getMovieDirector() {
	return movieDirector;
}
public void setMovieDirector(String movieDirector) {
	this.movieDirector = movieDirector;
}
public int getMovieLength() {
	return movieLength;
}
public void setMovieLength(int movieLength) {
	this.movieLength = movieLength;
}
public String getMovielanguage() {
	return movielanguage;
}
public void setMovielanguage(String movielanguage) {
	this.movielanguage = movielanguage;
}
public String getMovieReleaseDate() {
	return movieReleaseDate;
}
public void setMovieRealeaseDate(String movieReleaseDate) {
	this.movieReleaseDate = movieReleaseDate;
}

   
}
