package com.cg.sprint.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

public class RestControllerException extends ResponseEntityExceptionHandler
{
	@ExceptionHandler(InvalidMovieIdException.class)
    @ResponseBody
	public ResponseEntity<Object> handleInvalidTheater(InvalidMovieIdException e) 
	{
		System.out.println("Exception: " + e.getMessage());
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}

}