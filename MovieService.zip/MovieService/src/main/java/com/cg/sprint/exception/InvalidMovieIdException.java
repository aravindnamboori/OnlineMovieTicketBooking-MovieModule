package com.cg.sprint.exception;

@SuppressWarnings("serial")
public class InvalidMovieIdException extends Exception
{
	public InvalidMovieIdException()
	{
		super();
	}
	public InvalidMovieIdException(String message)
	{
		super(message);
	}

}
